import Link from 'next/link'
import { redirect } from 'next/navigation'
import type { ReactNode } from 'react'
import { LogOut } from 'lucide-react'
import { SiteHeader } from '@/components/site/site-header'
import { SiteFooter } from '@/components/site/site-footer'
import { Container } from '@/components/ui/primitives'
import { chapterTitle } from '@/components/story/talent-avatar'
import { getDictionary } from '@/lib/i18n/dictionary'
import { fill } from '@/lib/i18n/format'
import { pagePath, type Locale } from '@/lib/i18n/routes'
import { serverSupabase } from '@/lib/supabase/server'

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-1 py-4 sm:flex-row sm:items-baseline sm:gap-6">
      <dt className="w-44 shrink-0 text-[14px] text-faint">{label}</dt>
      <dd className="min-w-0 text-[16px] text-ink [overflow-wrap:anywhere]">{children}</dd>
    </div>
  )
}

/** Das eigene Konto: liest nur, was RLS dem angemeldeten Konto erlaubt. */
export async function AccountPage({ locale }: { locale: Locale }) {
  const supabase = await serverSupabase()
  if (!supabase) redirect(`${pagePath('signIn', locale)}?error=unavailable`)
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) redirect(pagePath('signIn', locale))

  const [profile, freelancer] = await Promise.all([
    supabase.from('profiles').select('full_name').eq('id', user.id).maybeSingle(),
    supabase.from('freelancers').select('first_name, role_title, status').eq('user_id', user.id).maybeSingle(),
  ])
  const dict = getDictionary(locale)
  const copy = dict.account
  const firstName = (profile.data?.full_name as string | null)?.trim().split(/\s+/)[0] || (freelancer.data?.first_name as string | null) || null
  const methods = [...new Set((user.identities ?? []).map((identity) => identity.provider))].map((provider) => copy.methodNames[provider] ?? provider)

  return (
    <>
      <SiteHeader />
      <main>
        <section className="py-14 md:py-24" aria-labelledby="konto-title">
          <Container className="flex max-w-[860px] flex-col gap-8">
            <div className="flex flex-col gap-5">
              <p className="text-[14px] text-faint">{copy.label}</p>
              <h1 id="konto-title" className={`${chapterTitle} text-ink`}>
                {firstName ? fill(copy.hello, { name: firstName }) : copy.helloPlain}
              </h1>
            </div>

            <dl className="divide-y divide-line rounded-[28px] border border-line bg-white px-6 sm:px-8">
              <Row label={copy.email}>{user.email ?? '–'}</Row>
              <Row label={copy.methods}>{methods.length ? methods.join(' · ') : '–'}</Row>
              <Row label={copy.freelancer}>
                {freelancer.data ? (
                  <>
                    {(freelancer.data.role_title as string | null) ?? '–'}{' '}
                    <span className="ml-1 rounded-full bg-surface px-2.5 py-1 text-[13px] text-muted">
                      {copy.status[freelancer.data.status as string] ?? (freelancer.data.status as string)}
                    </span>
                  </>
                ) : (
                  <>
                    {copy.noFreelancer}{' '}
                    <Link href={pagePath('freelancer', locale)} className="font-medium underline-offset-4 hover:underline">
                      {copy.createProfile}
                    </Link>
                  </>
                )}
              </Row>
            </dl>

            <p className="text-[14px] text-muted">{copy.next}</p>

            <form action="/auth/sign-out" method="post">
              <input type="hidden" name="lang" value={locale} />
              <button
                type="submit"
                className="inline-flex h-11 items-center gap-2 rounded-full border border-line-strong px-5 text-[15px] font-medium text-ink transition-colors hover:border-ink/50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand"
              >
                <LogOut aria-hidden size={16} strokeWidth={1.75} />
                {copy.signOut}
              </button>
            </form>
          </Container>
        </section>
      </main>
      <SiteFooter locale={locale} />
    </>
  )
}
