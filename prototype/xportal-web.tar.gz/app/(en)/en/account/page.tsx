import type { Metadata } from 'next'
import { AccountPage } from '@/components/pages/account-page'
import { pageMetadata } from '@/lib/i18n/metadata'

export const metadata: Metadata = { ...pageMetadata('account', 'en'), robots: { index: false, follow: false } }

export default function Page() {
  return <AccountPage locale="en" />
}
