import { NextResponse } from 'next/server'
import { pagePath } from '@/lib/i18n/routes'
import { safePath } from '@/lib/supabase/env'
import { serverSupabase } from '@/lib/supabase/server'

// Rückweg von Google, LinkedIn, GitHub und vom E-Mail-Link: Code gegen eine Sitzung tauschen, dann ins Konto.

export async function GET(request: Request) {
  const url = new URL(request.url)
  const locale = url.searchParams.get('lang') === 'en' ? 'en' : 'de'
  const failed = (reason: string) => NextResponse.redirect(new URL(`${pagePath('signIn', locale)}?error=${reason}`, url.origin))

  const code = url.searchParams.get('code')
  // Lehnt der Anbieter ab oder bricht jemand ab, kommt statt eines Codes ein Fehler zurück.
  if (!code) return failed(url.searchParams.get('error') ? 'provider' : 'missing_code')

  const supabase = await serverSupabase()
  if (!supabase) return failed('unavailable')
  const { error } = await supabase.auth.exchangeCodeForSession(code)
  if (error) {
    console.error(JSON.stringify({ event: 'auth_exchange_failed', code: error.code ?? error.name }))
    return failed('exchange')
  }
  return NextResponse.redirect(new URL(safePath(url.searchParams.get('next'), pagePath('account', locale)), url.origin))
}
