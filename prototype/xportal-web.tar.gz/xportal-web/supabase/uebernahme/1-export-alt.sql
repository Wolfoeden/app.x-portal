-- Schritt 1, im alten Projekt (x-portal.eu, xmoxzfqmcnsntvqxhtfb) ausführen. Liest nur.
-- Ergebnis: eine Zeile mit payload (jsonb). Nur Freelancer mit eigenem Konto; vom Betreiber angelegte Profile bleiben zurück.
-- Ohne Passwort-Hashes: Die neue Anmeldung läuft über Magic Link und OAuth.
with own as (
  select * from public.freelancer_profiles where owner_user_id is not null
)
select jsonb_build_object(
  'users', (
    select coalesce(jsonb_agg(to_jsonb(u)), '[]'::jsonb) from (
      select id, email, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at, last_sign_in_at
        from auth.users where id in (select owner_user_id from own)
    ) u),
  'identities', (
    select coalesce(jsonb_agg(to_jsonb(i)), '[]'::jsonb) from (
      select id, user_id, provider_id, provider, identity_data, last_sign_in_at, created_at, updated_at
        from auth.identities where user_id in (select owner_user_id from own)
    ) i),
  'profiles', (
    select coalesce(jsonb_agg(to_jsonb(p)), '[]'::jsonb) from (
      select id, owner_user_id, display_name, role_title, skill_tags, languages, location_text, work_modes,
             experience_summary, verification_status, day_rate_minor, hourly_rate_minor, availability_status,
             availability_from, profile_links, avatar_path, profile_status, created_at
        from own
    ) p),
  'projects', (
    select coalesce(jsonb_agg(to_jsonb(x)), '[]'::jsonb) from (
      select pr.profile_id, pr.position, pr.title, pr.client_label, pr.industry, pr.project_role, pr.started_on,
             pr.ended_on, pr.ongoing, pr.technologies, pr.outcome, pr.link_url, pr.is_public, pr.created_at
        from public.freelancer_projects pr where pr.profile_id in (select id from own)
    ) x),
  'cvs', (
    select coalesce(jsonb_agg(to_jsonb(d)), '[]'::jsonb) from (
      select profile_id, storage_bucket, storage_path, original_filename, mime_type, byte_size, version, uploaded_at
        from public.freelancer_cv_documents where profile_id in (select id from own)
    ) d),
  'stripe_customers', (
    select coalesce(jsonb_agg(to_jsonb(s)), '[]'::jsonb) from (
      select user_id, stripe_customer_id from public.user_ai_credit_accounts
       where stripe_customer_id is not null and user_id in (select owner_user_id from own)
    ) s)
) as payload;
