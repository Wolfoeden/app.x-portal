import type { NextConfig } from 'next'

// STATIC_EXPORT=1 baut eine statische Vorschau (Netlify-Vorschauseite ohne Server).
const staticExport = process.env.STATIC_EXPORT === '1'

const nextConfig: NextConfig = {
  poweredByHeader: false,
  // Zwei Root-Layouts (Deutsch und Englisch) brauchen eine eigene, globale 404.
  experimental: { globalNotFound: true },
  ...(staticExport ? { output: 'export' as const, images: { unoptimized: true } } : {}),
}

export default nextConfig
