import type { Brief } from '@/lib/ai/brief'
import type { Dictionary } from '@/lib/i18n/dictionary'
import { euro, fill } from '@/lib/i18n/format'
import type { Locale } from '@/lib/i18n/routes'
import type { Requirement, Scenario, TeamMember } from '@/lib/demo/scenarios'
import { initialsOf } from '@/lib/freelancer/profile'
import { coveredSkill, type Candidate } from '@/lib/matching/team'

// Echte Treffer in der Form der Beispielszenarien, damit alle Kapitel sie unverändert zeigen.
// Ohne Einwilligung „showcase“ steht statt des Vornamens die Rolle; Kontaktdaten gibt es hier nie.

type Input = { text: string; brief: Brief; team: Candidate[]; dict: Dictionary; locale: Locale; stamp: string }

export function toLiveScenario({ text, brief, team, dict, locale, stamp }: Input): Scenario {
  const live = dict.live
  const roleLabel = (candidate: Candidate) => dict.freelancer.roles.find((role) => role.id === candidate.roleKey)?.label ?? live.profile
  const nameOf = (candidate: Candidate) => (candidate.showcase ? candidate.firstName : roleLabel(candidate))

  const members: TeamMember[] = team.map((candidate) => {
    const matched = brief.requiredSkills.map((need) => coveredSkill(need, candidate)).filter((skill): skill is string => Boolean(skill))
    const why = (matched.length ? matched : candidate.skills).slice(0, 2)
    return {
      id: candidate.id,
      why,
      from: live.availability[candidate.availability ?? 'open'],
      role: candidate.roleTitle ?? roleLabel(candidate),
      talent: {
        id: candidate.id,
        name: nameOf(candidate),
        initials: initialsOf(nameOf(candidate)) || '·',
        tone: dict.freelancer.roles.find((role) => role.id === candidate.roleKey)?.tone ?? 'stone',
        onSite: candidate.workMode !== null && candidate.workMode !== 'remote',
      },
    }
  })

  const requirements: Requirement[] = brief.requiredSkills.slice(0, 5).map((need) => {
    const holder = team.find((candidate) => coveredSkill(need, candidate))
    return { label: need, met: Boolean(holder), by: holder ? `${nameOf(holder)}, ${coveredSkill(need, holder)}` : live.open }
  })
  if (brief.workMode === 'onsite') {
    const onSite = team.filter((candidate) => candidate.workMode === 'onsite' || candidate.workMode === 'both')
    requirements.push({ label: live.onSite, met: onSite.length > 0, by: onSite.length ? onSite.map(nameOf).join(', ') : live.open })
  }
  if (!requirements.length) {
    for (const role of brief.roles) {
      const holder = team.find((candidate) => candidate.roleKey === role)
      const label = dict.freelancer.roles.find((item) => item.id === role)?.label ?? role
      requirements.push({ label, met: Boolean(holder), by: holder ? nameOf(holder) : live.open })
    }
  }

  const lead = team[0]
  const teamRate = team.reduce((sum, candidate) => sum + (candidate.dayRate ?? 0), 0)
  const budget = brief.budgetEur
    ? euro(brief.budgetEur, locale)
    : brief.durationDays && teamRate
      ? fill(live.estimate, { amount: euro(Math.round((teamRate * brief.durationDays) / 100) * 100, locale) })
      : teamRate
        ? fill(live.perDay, { amount: euro(teamRate, locale) })
        : live.availability.open

  return {
    id: `live-${stamp}`,
    source: 'live',
    chip: '',
    sentence: text,
    title: brief.title,
    keywords: [],
    team: members,
    rate: lead?.dayRate ? fill(live.rate, { amount: euro(lead.dayRate, locale) }) : live.availability.open,
    requirements,
    deliveries: brief.deliverables,
    budget,
  }
}
