import 'server-only'

import type { SupabaseClient } from '@supabase/supabase-js'
import { briefEmbeddingText } from '@/lib/ai/brief'
import { createAi, type Ai, type Usage } from '@/lib/ai/openai'
import type { Scenario } from '@/lib/demo/scenarios'
import type { Availability, RoleId, WorkMode } from '@/lib/freelancer/profile'
import { getDictionary } from '@/lib/i18n/dictionary'
import type { Locale } from '@/lib/i18n/routes'
import { toLiveScenario } from '@/lib/matching/live-scenario'
import { inputHash, pickTeam, profileText, type Candidate } from '@/lib/matching/team'
import { aiConfig, type AiConfig } from '@/lib/server/env'
import { supabaseAdmin } from '@/lib/server/supabase-admin'

// Ein Satz → Brief (OpenAI) → Vorauswahl (pgvector) → Team. Jeder Fehler endet in der Demo, nie in einer kaputten Seite.

export type DemoReason = 'not_configured' | 'limit' | 'budget' | 'no_match' | 'error'
export type AnalyseResult = { mode: 'live'; scenario: Scenario } | { mode: 'demo'; reason: DemoReason }

type Deps = { config: AiConfig | null; db: SupabaseClient | null; ai?: Ai }

type FreelancerRow = {
  id: string
  first_name: string
  role_title: string | null
  role_key: RoleId | null
  headline: string | null
  skills: string[]
  about: string | null
  availability: Availability | null
  work_mode: WorkMode | null
  day_rate_eur: number | null
}

async function recordUsage(db: SupabaseClient, usage: Usage) {
  const { error } = await db
    .from('ai_usage')
    .insert({ kind: usage.kind, model: usage.model.slice(0, 120), input_tokens: usage.inputTokens, output_tokens: usage.outputTokens })
  if (error) console.error(JSON.stringify({ event: 'ai_usage_failed', code: error.code }))
}

export async function analyse(
  { text, locale, visitor }: { text: string; locale: Locale; visitor: string | null },
  deps: Deps = { config: aiConfig(), db: supabaseAdmin() },
): Promise<AnalyseResult> {
  const { config, db } = deps
  if (!config || !db || !visitor) return { mode: 'demo', reason: 'not_configured' }

  try {
    const allowed = await db.rpc('consume_rate_limit', {
      p_bucket: 'analyse',
      p_key: visitor,
      p_max: config.analysesPerVisitorPerDay,
      p_window_seconds: 86_400,
    })
    if (allowed.error) throw allowed.error
    if (allowed.data !== true) return { mode: 'demo', reason: 'limit' }

    const used = await db.rpc('ai_tokens_this_month')
    if (used.error) throw used.error
    if (Number(used.data) >= config.monthlyTokenLimit) return { mode: 'demo', reason: 'budget' }

    const ai = deps.ai ?? createAi(config)
    const { brief, usage } = await ai.brief(text, locale, visitor.slice(0, 32))
    await recordUsage(db, usage)

    // Fingerabdrücke: nur neu rechnen, was sich seit dem letzten Mal geändert hat.
    const profiles = await db
      .from('freelancers')
      .select('id, first_name, role_title, role_key, headline, skills, about, availability, work_mode, day_rate_eur')
      .eq('status', 'published')
      .limit(1_000)
    if (profiles.error) throw profiles.error
    const rows = (profiles.data ?? []) as FreelancerRow[]
    const stored = await db.from('freelancer_embeddings').select('freelancer_id, input_hash, model')
    if (stored.error) throw stored.error
    const known = new Map((stored.data ?? []).map((row) => [row.freelancer_id as string, `${row.model}:${row.input_hash}`]))
    const stale = rows
      .map((row) => {
        const content = profileText({ roleTitle: row.role_title, headline: row.headline, skills: row.skills, about: row.about })
        return { id: row.id, content, hash: inputHash(content, ai.embeddingModel) }
      })
      .filter((row) => known.get(row.id) !== `${ai.embeddingModel}:${row.hash}`)

    const embedded = await ai.embed([briefEmbeddingText(brief), ...stale.map((row) => row.content)])
    await recordUsage(db, embedded.usage)
    const [query, ...fresh] = embedded.vectors
    if (stale.length) {
      const upsert = await db.from('freelancer_embeddings').upsert(
        stale.map((row, index) => ({ freelancer_id: row.id, input_hash: row.hash, model: ai.embeddingModel, embedding: fresh[index], created_at: new Date().toISOString() })),
      )
      if (upsert.error) throw upsert.error
    }

    const matches = await db.rpc('match_freelancers', {
      p_embedding: query,
      p_model: ai.embeddingModel,
      p_work_mode: brief.workMode === 'unknown' ? null : brief.workMode,
      p_limit: 20,
    })
    if (matches.error) throw matches.error
    const similarity = new Map(((matches.data ?? []) as { freelancer_id: string; similarity: number }[]).map((row) => [row.freelancer_id, row.similarity]))
    if (!similarity.size) return { mode: 'demo', reason: 'no_match' }

    const showcase = await db.from('showcase_profiles').select('freelancer_id').in('freelancer_id', [...similarity.keys()])
    if (showcase.error) throw showcase.error
    const consented = new Set((showcase.data ?? []).map((row) => row.freelancer_id as string))

    const candidates: Candidate[] = rows
      .filter((row) => similarity.has(row.id))
      .map((row) => ({
        id: row.id,
        similarity: similarity.get(row.id)!,
        firstName: row.first_name,
        showcase: consented.has(row.id),
        roleTitle: row.role_title,
        roleKey: row.role_key,
        skills: row.skills,
        availability: row.availability,
        workMode: row.work_mode,
        dayRate: row.day_rate_eur,
      }))
    const team = pickTeam(brief, candidates)
    if (!team.length) return { mode: 'demo', reason: 'no_match' }

    return {
      mode: 'live',
      scenario: toLiveScenario({ text, brief, team, dict: getDictionary(locale), locale, stamp: Date.now().toString(36) }),
    }
  } catch (error) {
    // Keine Inhalte ins Log: nur, wo es scheiterte.
    const detail = error instanceof Error ? error.name : typeof error === 'object' && error && 'code' in error ? String(error.code) : 'unknown'
    console.error(JSON.stringify({ event: 'analyse_failed', detail }))
    return { mode: 'demo', reason: 'error' }
  }
}
