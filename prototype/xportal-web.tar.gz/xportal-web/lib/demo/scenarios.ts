// Demo-Motor für die Startseite: ordnet einen Satz einem Beispielszenario zu.
// Später ersetzt die echte Gastanalyse diesen Motor; die Oberfläche bleibt gleich.
// Die Texte der Szenarien und Rollen stehen je Sprache in lib/i18n.

export type Tone = 'green' | 'amber' | 'slate' | 'stone'

export type Talent = {
  id: string
  name: string
  initials: string
  tone: Tone
  onSite: boolean
}

export type Requirement = { label: string; met: boolean; by: string }

export type ScenarioId = 'chatbot' | 'automation' | 'analytics' | 'isms'

export type Scenario = {
  id: ScenarioId
  chip: string
  sentence: string
  title: string
  keywords: string[]
  team: { id: string; why: string[]; from: string }[]
  rate: string
  requirements: Requirement[]
  deliveries: string[]
  budget: string
}

export const TALENTS: Talent[] = [
  { id: 'mara', name: 'Mara', initials: 'MA', tone: 'green', onSite: true },
  { id: 'leon', name: 'Leon', initials: 'LE', tone: 'amber', onSite: true },
  { id: 'eva', name: 'Eva', initials: 'EV', tone: 'slate', onSite: true },
  { id: 'noah', name: 'Noah', initials: 'NO', tone: 'stone', onSite: false },
  { id: 'jonas', name: 'Jonas', initials: 'JO', tone: 'green', onSite: false },
  { id: 'aylin', name: 'Aylin', initials: 'AY', tone: 'slate', onSite: true },
  { id: 'sara', name: 'Sara', initials: 'SA', tone: 'amber', onSite: false },
  { id: 'clara', name: 'Clara', initials: 'CL', tone: 'stone', onSite: false },
  { id: 'tobias', name: 'Tobias', initials: 'TO', tone: 'green', onSite: true },
  { id: 'lena', name: 'Lena', initials: 'LN', tone: 'amber', onSite: false },
  { id: 'malik', name: 'Malik', initials: 'MK', tone: 'slate', onSite: true },
  { id: 'ines', name: 'Ines', initials: 'IN', tone: 'stone', onSite: false },
  { id: 'paul', name: 'Paul', initials: 'PA', tone: 'green', onSite: false },
  { id: 'yara', name: 'Yara', initials: 'YA', tone: 'amber', onSite: true },
  { id: 'ben', name: 'Ben', initials: 'BE', tone: 'slate', onSite: false },
  { id: 'mira', name: 'Mira', initials: 'MI', tone: 'stone', onSite: false },
]

export const talentById = new Map(TALENTS.map((talent) => [talent.id, talent]))

// Lange Schlüsselwörter dürfen in zusammengesetzten Wörtern stecken („Kundenservice“), kurze nur am Wortanfang („bi“ nicht in „bis“).
function hasKeyword(text: string, tokens: string[], keyword: string) {
  return keyword.length > 3 ? text.includes(keyword) : tokens.some((token) => token === keyword || (keyword.length === 3 && token.startsWith(keyword)))
}

/** Wählt das Szenario mit den meisten Treffern; ohne Treffer bleibt es beim ersten (Chatbot). */
export function matchScenario(text: string, scenarios: Scenario[]): Scenario {
  const words = text.toLowerCase()
  const tokens = words.split(/[^a-z0-9äöüß]+/).filter(Boolean)
  let best = scenarios[0]
  let bestScore = 0
  for (const scenario of scenarios) {
    const score = scenario.keywords.reduce((sum, keyword) => (hasKeyword(words, tokens, keyword) ? sum + 1 : sum), 0)
    if (score > bestScore) {
      best = scenario
      bestScore = score
    }
  }
  return best
}

/** „2 vor Ort · 2 remote“ in der Sprache der Seite. */
export function composition(scenario: Scenario, words: { onSite: string; remote: string }): string {
  const onSite = scenario.team.filter((member) => talentById.get(member.id)?.onSite).length
  const remote = scenario.team.length - onSite
  if (!onSite) return `${remote} ${words.remote}`
  if (!remote) return `${onSite} ${words.onSite}`
  return `${onSite} ${words.onSite} · ${remote} ${words.remote}`
}
