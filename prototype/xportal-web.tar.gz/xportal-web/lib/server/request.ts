import 'server-only'

import { createHmac } from 'node:crypto'

// Nach dem Muster von lib/security/request.ts im alten Repo.

const SAME_SITE_FETCH = new Set(['same-origin', 'same-site'])

/** Schreibende Anfragen nur von der eigenen Seite. `Sec-Fetch-Site` setzt der Browser selbst, Skripte können ihn nicht fälschen. */
export function isSameOrigin(request: Request) {
  const fetchSite = request.headers.get('sec-fetch-site')?.trim().toLowerCase()
  if (fetchSite && !SAME_SITE_FETCH.has(fetchSite)) return false
  const origin = request.headers.get('origin')
  if (!origin) return Boolean(fetchSite && SAME_SITE_FETCH.has(fetchSite))
  const allowed = new Set([new URL(request.url).origin])
  const host = request.headers.get('host')?.trim()
  if (host) allowed.add(`${new URL(request.url).protocol}//${host}`)
  const site = process.env.NEXT_PUBLIC_SITE_URL?.trim()
  if (site) allowed.add(new URL(site).origin)
  return allowed.has(origin)
}

export async function readJson(request: Request, maximumBytes = 8_000): Promise<unknown> {
  const body = await request.text()
  if (new TextEncoder().encode(body).byteLength > maximumBytes) throw new Error('too_large')
  return JSON.parse(body) as unknown
}

function clientIp(request: Request) {
  // Auf Netlify setzt die Plattform diesen Header; vom Client gesendete Werte überschreibt sie.
  if (process.env.NETLIFY === 'true') return request.headers.get('x-nf-client-connection-ip')?.trim() || 'unknown'
  if (process.env.NODE_ENV !== 'production') return request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local'
  return 'unknown'
}

/** Schlüssel ohne Personenbezug für das Rate-Limit: HMAC der IP. */
export function visitorKey(request: Request) {
  const secret = process.env.IP_HASH_SECRET?.trim()
  if ((!secret || secret.length < 32) && process.env.NODE_ENV === 'production') return null
  return createHmac('sha256', secret || 'nur-lokal').update(`ip:${clientIp(request)}`).digest('hex')
}
