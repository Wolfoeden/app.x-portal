import type { Metadata } from 'next'
import { getDictionary } from '@/lib/i18n/dictionary'
import { PAGES, type Locale, type PageKey } from '@/lib/i18n/routes'

/** Titel, Beschreibung, Canonical und hreflang einer Seite. x-default zeigt auf Deutsch. */
export function pageMetadata(page: PageKey, locale: Locale): Metadata {
  const meta = getDictionary(locale).meta[page]
  const paths = PAGES[page]
  return {
    title: meta.title,
    description: meta.description,
    alternates: {
      canonical: paths[locale],
      languages: { de: paths.de, en: paths.en, 'x-default': paths.de },
    },
    openGraph: {
      title: meta.title,
      description: meta.description,
      url: paths[locale],
      locale: locale === 'de' ? 'de_DE' : 'en_GB',
      siteName: 'XPORTAL',
      type: 'website',
    },
  }
}

/** Gemeinsame Basis beider Root-Layouts. Im Prototyp ist SITE_URL die Vorschau. */
export const siteMetadata: Metadata = {
  metadataBase: new URL(process.env.SITE_URL ?? 'https://xportal-vorschau.netlify.app'),
}
