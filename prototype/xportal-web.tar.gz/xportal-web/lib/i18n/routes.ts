// Seiten und Anker je Sprache. Deutsch ohne Präfix, Englisch unter /en.

export const LOCALES = ['de', 'en'] as const
export type Locale = (typeof LOCALES)[number]

export const PAGES = {
  home: { de: '/', en: '/en' },
  freelancer: { de: '/freelancer', en: '/en/freelancers' },
  investors: { de: '/investoren', en: '/en/investors' },
} as const
export type PageKey = keyof typeof PAGES

/** Anker-IDs je Sprache, damit Adressen wie /en#deck lesbar bleiben. */
export const IDS = {
  de: {
    project: 'projekt',
    reasons: 'begruendung',
    platform: 'plattform',
    data: 'daten',
    hubs: 'hubs',
    start: 'einstieg',
    team: 'team',
    services: 'leistungen',
    pricing: 'preise',
    contact: 'kontakt',
    imprint: 'impressum',
    privacy: 'datenschutz',
    terms: 'agb',
    signIn: 'anmelden',
    doorCompanies: 'unternehmen',
    doorFreelancers: 'freelancer',
    doorInvestors: 'investoren',
    profile: 'profil',
    requests: 'anfragen',
    private: 'privat',
    workplace: 'arbeitsort',
    costs: 'kosten',
    faq: 'fragen',
    loop: 'kreislauf',
    whyNow: 'warum-jetzt',
    revenue: 'erloese',
    hub01: 'hub-01',
    roadmap: 'roadmap',
    deck: 'deck',
  },
  en: {
    project: 'project',
    reasons: 'reasons',
    platform: 'platform',
    data: 'data',
    hubs: 'hubs',
    start: 'start',
    team: 'team',
    services: 'services',
    pricing: 'pricing',
    contact: 'contact',
    imprint: 'imprint',
    privacy: 'privacy',
    terms: 'terms',
    signIn: 'sign-in',
    doorCompanies: 'companies',
    doorFreelancers: 'freelancers',
    doorInvestors: 'investors',
    profile: 'profile',
    requests: 'requests',
    private: 'private',
    workplace: 'workplace',
    costs: 'costs',
    faq: 'faq',
    loop: 'flywheel',
    whyNow: 'why-now',
    revenue: 'revenue',
    hub01: 'hub-01',
    roadmap: 'roadmap',
    deck: 'deck',
  },
} satisfies Record<Locale, Record<string, string>>
export type Ids = (typeof IDS)['de']
export type IdKey = keyof Ids

export function pagePath(page: PageKey, locale: Locale) {
  return PAGES[page][locale]
}

/** Pfad mit Anker, z. B. pageHref('home', 'en', 'deck') → /en#deck. */
export function pageHref(page: PageKey, locale: Locale, anchor?: IdKey) {
  const path = PAGES[page][locale]
  return anchor ? `${path}#${IDS[locale][anchor]}` : path
}

/** Welche Seite ein Pfad ist, egal in welcher Sprache. */
export function pageOf(pathname: string): { page: PageKey; locale: Locale } | null {
  const clean = pathname.length > 1 ? pathname.replace(/\/$/, '') : pathname
  for (const page of Object.keys(PAGES) as PageKey[]) {
    for (const locale of LOCALES) if (PAGES[page][locale] === clean) return { page, locale }
  }
  return null
}

/** Der gleiche Anker in der anderen Sprache, falls es ihn gibt. */
export function translateAnchor(hash: string, from: Locale, to: Locale) {
  const id = hash.replace(/^#/, '')
  const key = (Object.keys(IDS[from]) as IdKey[]).find((item) => IDS[from][item] === id)
  return key ? `#${IDS[to][key]}` : ''
}
