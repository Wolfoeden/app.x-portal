import type { Talent, Tone } from '@/lib/demo/scenarios'

export const toneClass: Record<Tone, string> = {
  green: 'bg-brand-soft text-brand-ink',
  amber: 'bg-amber-soft text-amber-ink',
  slate: 'bg-[#e3ecef] text-[#24515e]',
  stone: 'bg-surface-2 text-body',
}

export function TalentAvatar({ talent, size, className = '' }: { talent: Talent; size: number; className?: string }) {
  return (
    <span
      aria-hidden
      className={`grid shrink-0 place-items-center rounded-full font-semibold ${toneClass[talent.tone]} ${className}`}
      style={{ width: size, height: size, fontSize: Math.round(size * 0.34) }}
    >
      {talent.initials}
    </span>
  )
}

export function ChapterLabel({ number, children, tone = 'dark' }: { number: string; children: string; tone?: 'dark' | 'light' }) {
  return (
    <p className={`flex items-center gap-3 text-[13px] tracking-[0.02em] ${tone === 'light' ? 'text-[#bfd8c8]' : 'text-faint'}`}>
      <span className="tabular-nums">{number}</span>
      <span aria-hidden className={`h-px w-8 ${tone === 'light' ? 'bg-[#bfd8c8]/50' : 'bg-line-strong'}`} />
      {children}
    </p>
  )
}

export const chapterTitle = 'text-[clamp(2.5rem,5.4vw,4.75rem)] font-medium leading-[0.98] tracking-[-0.04em] text-balance'
