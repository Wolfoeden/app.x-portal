'use client'

import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react'
import type { Scenario } from '@/lib/demo/scenarios'
import { useLocale } from '@/components/i18n/locale-provider'

// Das Projekt aus dem Aufmacher trägt durch alle Kapitel. Ohne eigene Eingabe gilt das Beispiel.
type Ask = { sentence: string; id: number }

type Story = {
  scenario: Scenario
  query: string | null
  setStory: (scenario: Scenario, query: string | null) => void
  ask: Ask | null
  askFor: (sentence: string) => void
}

const StoryContext = createContext<Story | null>(null)

export function StoryProvider({ children }: { children: ReactNode }) {
  const { dict } = useLocale()
  const [scenario, setScenario] = useState<Scenario>(dict.scenarios[0])
  const [query, setQuery] = useState<string | null>(null)
  const [ask, setAsk] = useState<Ask | null>(null)

  const setStory = useCallback((next: Scenario, nextQuery: string | null) => {
    setScenario(next)
    setQuery(nextQuery)
  }, [])

  const askFor = useCallback((sentence: string) => {
    setAsk({ sentence, id: Date.now() })
  }, [])

  const value = useMemo(() => ({ scenario, query, setStory, ask, askFor }), [scenario, query, setStory, ask, askFor])
  return <StoryContext.Provider value={value}>{children}</StoryContext.Provider>
}

export function useStory() {
  const story = useContext(StoryContext)
  if (!story) throw new Error('useStory braucht den StoryProvider')
  return story
}
