'use client'

import { useRef, useState, type ReactNode } from 'react'
import { AnimatePresence, motion, useMotionValueEvent, useReducedMotion, useScroll } from 'motion/react'
import { Check, FileSignature, Lock, Mail } from 'lucide-react'
import { Container } from '@/components/ui/primitives'
import { DiscordLogo, SlackLogo } from '@/components/brand/channel-logos'
import { useStory } from '@/components/story/story-context'
import { ChapterLabel, TalentAvatar, chapterTitle } from '@/components/story/talent-avatar'
import { composition, roleOf, talentOf, type Scenario } from '@/lib/demo/scenarios'
import { useLocale } from '@/components/i18n/locale-provider'
import type { Dictionary } from '@/lib/i18n/dictionary'
import { fill } from '@/lib/i18n/format'

function StepBody({ step, scenario, query, dict }: { step: number; scenario: Scenario; query: string | null; dict: Dictionary }) {
  const copy = dict.home.workspace
  if (step === 0) {
    return (
      <div className="flex flex-col gap-4">
        <p className="text-[18px] leading-snug text-ink">{fill(dict.common.quote, { text: query ?? scenario.sentence })}</p>
        <div className="flex flex-wrap gap-2">
          {scenario.requirements.map((item) => (
            <span key={item.label} className="rounded-full bg-surface px-3 py-1.5 text-[13px] text-body">
              {item.label}
            </span>
          ))}
        </div>
        <p className="text-[13px] text-faint">{copy.briefNote}</p>
      </div>
    )
  }
  if (step === 1) {
    return (
      <div className="flex flex-col gap-3">
        {scenario.team.map((member) => {
          const talent = talentOf(member)
          return (
            <div key={member.id} className="flex items-center gap-3">
              <TalentAvatar talent={talent} size={36} />
              <p className="min-w-0 flex-1 truncate text-[15px] text-ink">
                <span className="font-medium">{talent.name}</span>
                <span className="text-faint"> · {roleOf(member, dict.talentRoles)}</span>
              </p>
              <span className={`rounded-full px-2 py-0.5 text-[12px] font-medium ${talent.onSite ? 'bg-brand-soft text-brand-ink' : 'bg-surface text-muted'}`}>
                {talent.onSite ? dict.common.onSite : dict.common.remote}
              </span>
            </div>
          )
        })}
        <p className="text-[13px] text-faint">{fill(copy.teamNote, { composition: composition(scenario, dict.common.composition) })}</p>
      </div>
    )
  }
  if (step === 2) {
    return (
      <ul className="flex flex-col gap-3">
        {scenario.deliveries.map((item) => (
          <li key={item} className="flex items-center gap-3 text-[16px] text-ink">
            <span className="grid size-6 place-items-center rounded-full bg-brand text-white">
              <Check aria-hidden size={14} strokeWidth={2.5} />
            </span>
            {item}
          </li>
        ))}
        <li className="text-[13px] text-faint">{copy.deliveryNote}</li>
      </ul>
    )
  }
  if (step === 3) {
    return (
      <div className="flex flex-col gap-4">
        <p className="text-[18px] text-ink">{copy.acceptanceTitle}</p>
        <div className="flex flex-wrap gap-2">
          <span className="inline-flex h-10 items-center rounded-full bg-brand px-4 text-[14px] font-medium text-white">{copy.acceptDigital}</span>
          <span className="inline-flex h-10 items-center gap-1.5 rounded-full border border-line-strong px-4 text-[14px] font-medium text-ink">
            <FileSignature aria-hidden size={15} strokeWidth={1.75} />
            {copy.acceptPdf}
          </span>
        </div>
        <p className="text-[13px] text-faint">{copy.acceptanceNote}</p>
      </div>
    )
  }
  return (
    <div className="flex flex-col gap-3">
      <p className="text-[13px] text-faint">{copy.paymentLabel}</p>
      <p className="text-[40px] font-medium leading-none tracking-[-0.03em] text-ink tabular-nums">{scenario.budget}</p>
      <p className="text-[15px] text-muted">{copy.paymentNote}</p>
    </div>
  )
}

function Toast({ show, delay = 0, logo, title, text }: { show: boolean; delay?: number; logo: ReactNode; title: string; text: string }) {
  return (
    <AnimatePresence>
      {show ? (
        <motion.div
          initial={{ opacity: 0, x: 24 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 24 }}
          transition={{ type: 'spring', stiffness: 200, damping: 24, delay }}
          className="flex w-full items-start gap-3 rounded-2xl border border-line bg-white p-3 shadow-[0_1px_2px_rgb(14_20_17/0.05),0_16px_32px_-20px_rgb(14_20_17/0.3)]"
        >
          <span className="grid size-9 shrink-0 place-items-center rounded-[10px] border border-line bg-white">{logo}</span>
          <span className="min-w-0">
            <span className="block text-[14px] font-medium text-ink">{title}</span>
            <span className="block text-[12.5px] leading-snug text-muted">{text}</span>
          </span>
        </motion.div>
      ) : null}
    </AnimatePresence>
  )
}

export function ChapterWorkspace() {
  const { scenario, query } = useStory()
  const { dict, ids } = useLocale()
  const copy = dict.home.workspace
  const steps = copy.steps
  const reduceMotion = useReducedMotion()
  const trackRef = useRef<HTMLElement>(null)
  const [scrolledStep, setScrolledStep] = useState(0)
  const { scrollYProgress } = useScroll({ target: trackRef, offset: ['start start', 'end end'] })
  useMotionValueEvent(scrollYProgress, 'change', (value) => setScrolledStep(Math.max(0, Math.min(4, Math.floor(value * 5.4)))))
  const step = reduceMotion ? 4 : scrolledStep

  return (
    <section ref={trackRef} id={ids.platform} aria-labelledby="workspace-title" className={reduceMotion ? 'py-28' : 'relative h-[320vh]'}>
      <div className={reduceMotion ? '' : 'sticky top-16 flex h-[calc(100svh-4rem)] items-center overflow-hidden'}>
        <Container className="grid grid-cols-[minmax(0,1fr)] items-center gap-8 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] lg:gap-16">
          <div className="flex flex-col gap-5">
            <ChapterLabel number="03">{copy.label}</ChapterLabel>
            <h2 id="workspace-title" className={`${chapterTitle} text-ink`}>
              {copy.title}
            </h2>
            <p className="max-w-[420px] text-[18px] leading-relaxed text-muted">{copy.text}</p>
            <ol className="mt-4 hidden flex-col gap-1 lg:flex">
              {steps.map((label, index) => {
                const done = index < step
                const now = index === step
                return (
                  <li key={label} className={`flex items-center gap-3 py-1.5 text-[17px] transition-colors duration-300 ${now ? 'text-ink' : done ? 'text-brand-ink' : 'text-[#a3aaa5]'}`}>
                    <span
                      className={`grid size-7 place-items-center rounded-full text-[12px] font-semibold transition-colors duration-300 ${
                        now ? 'bg-ink text-white' : done ? 'bg-brand-soft text-brand-ink' : 'border border-line-strong'
                      }`}
                    >
                      {done ? <Check aria-hidden size={14} strokeWidth={2.5} /> : index + 1}
                    </span>
                    {label}
                  </li>
                )
              })}
            </ol>
          </div>

          <div className="relative">
            <div className="overflow-hidden rounded-[28px] border border-line bg-white shadow-[0_1px_2px_rgb(14_20_17/0.05),0_40px_80px_-40px_rgb(14_20_17/0.3)] lg:grid lg:grid-cols-[minmax(0,1fr)_250px]">
              <div className="p-5 sm:p-7">
                <div className="flex items-center justify-between gap-3">
                  <p className="truncate text-[14px] text-faint">{fill(copy.project, { title: scenario.title })}</p>
                  <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-surface px-2.5 py-1 text-[12px] text-muted">
                    <Lock aria-hidden size={12} strokeWidth={2} />
                    {copy.location}
                  </span>
                </div>
                <ol className="mt-4 flex gap-1.5">
                  {steps.map((label, index) => (
                    <li key={label} className="min-w-0 flex-1">
                      <span className={`block h-1.5 rounded-full transition-colors duration-500 ${index <= step ? 'bg-brand' : 'bg-surface-2'}`} />
                      <span className={`mt-2 block truncate text-[12px] ${index === step ? 'font-medium text-ink' : 'text-faint'}`}>{label}</span>
                    </li>
                  ))}
                </ol>
                <div className="mt-6 min-h-[230px]">
                  <AnimatePresence mode="wait" initial={false}>
                    <motion.div
                      key={`${scenario.id}-${step}`}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.28 }}
                    >
                      <StepBody step={step} scenario={scenario} query={query} dict={dict} />
                    </motion.div>
                  </AnimatePresence>
                </div>
              </div>

              <aside aria-label={copy.rail} className="hidden flex-col gap-3 border-l border-line bg-surface/60 p-4 lg:flex">
                <p className="px-1 text-[12.5px] text-faint">{copy.rail}</p>
                <Toast show={step >= 1} logo={<DiscordLogo className="size-[18px]" />} title="Discord" text={fill(copy.discordText, { n: scenario.team.length })} />
                <Toast show={step >= 2} delay={0.1} logo={<SlackLogo className="size-4" />} title={copy.slackTitle} text={fill(copy.slackText, { item: scenario.deliveries[0] })} />
                <Toast show={step >= 3} delay={0.1} logo={<Mail aria-hidden size={16} strokeWidth={1.75} className="text-ink" />} title={copy.emailTitle} text={copy.emailText} />
                <p className="mt-auto px-1 text-[12px] leading-snug text-faint">{copy.railNote}</p>
              </aside>
            </div>

            <p className="mt-4 flex items-center gap-2.5 text-[13px] text-muted lg:hidden">
              <SlackLogo className="size-4" />
              <DiscordLogo className="size-[17px]" />
              <Mail aria-hidden size={16} strokeWidth={1.75} className="text-ink" />
              {copy.mobileNote}
            </p>
          </div>
        </Container>
      </div>
    </section>
  )
}
