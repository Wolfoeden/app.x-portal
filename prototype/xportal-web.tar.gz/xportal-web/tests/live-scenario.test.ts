import { describe, expect, it } from 'vitest'
import { getDictionary } from '@/lib/i18n/dictionary'
import { toLiveScenario } from '@/lib/matching/live-scenario'
import { brief, candidate } from './fixtures'

const team = [
  candidate({ id: 'a', firstName: 'Vincent', showcase: true, roleKey: 'ki', roleTitle: 'AI Engineer', skills: ['Python', 'RAG'], dayRate: 760 }),
  candidate({ id: 'b', firstName: 'Marc', showcase: false, roleKey: 'isms', roleTitle: 'Auditor', skills: ['ISO 27001 Audits'], dayRate: 980, availability: null }),
]

describe('toLiveScenario', () => {
  const scenario = toLiveScenario({ text: 'Wir brauchen einen Chatbot.', brief, team, dict: getDictionary('de'), locale: 'de', stamp: 't' })

  it('zeigt den Vornamen nur mit Einwilligung, sonst die Rolle', () => {
    expect(scenario.team.map((member) => member.talent?.name)).toEqual(['Vincent', 'ISMS-Beratung'])
    expect(JSON.stringify(scenario)).not.toContain('Marc')
  })

  it('begründet mit den passenden Stärken und markiert Offenes', () => {
    expect(scenario.team[0].why).toEqual(['RAG'])
    expect(scenario.requirements).toEqual([
      { label: 'RAG', met: true, by: 'Vincent, RAG' },
      { label: 'ISO 27001', met: true, by: 'ISMS-Beratung, ISO 27001 Audits' },
    ])
    expect(scenario.team[1].from).toBe('nach Absprache')
  })

  it('nennt Tagessatz und Teamkosten in der Sprache der Seite', () => {
    expect(scenario.source).toBe('live')
    // Intl trennt Betrag und € mit einem geschützten Leerzeichen.
    expect(scenario.rate).toBe('760\u00a0€ / Tag')
    expect(scenario.budget).toBe('1.740\u00a0€ / Tag fürs Team')
    const english = toLiveScenario({ text: 'x', brief: { ...brief, durationDays: 20 }, team, dict: getDictionary('en'), locale: 'en', stamp: 't' })
    expect(english.rate).toBe('€760/day')
    expect(english.budget).toBe('approx. €34,800')
  })
})
